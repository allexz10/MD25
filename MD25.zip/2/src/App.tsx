import React, { useState } from 'react';
import './App.scss';

const App = () => {
  const [buttonCounter, setButtonCounter] = useState(0);
  const [xNumber, setXNumber] = useState(10);

  const clickHandle = () => {
    setButtonCounter(buttonCounter + 1);
    if (buttonCounter === xNumber) {
      setButtonCounter(buttonCounter - 2);
      setXNumber(xNumber - 2);
    } if (xNumber <= 0) {
      setXNumber(10);
      setButtonCounter(buttonCounter + 1);
    }
  };

  return (
    <div className="container">
      <button
        className="button"
        type="button"
        onClick={clickHandle}
      >
        {buttonCounter}
      </button>
    </div>
  );
};

export default App;
