import React, { useState } from 'react';

type Props = {
  nextButtonCounter: number;
};

const Button: React.FC<Props> = ({ nextButtonCounter }) => {
  const [currentButtonCounter, setCurrentButtonCounter] = useState(nextButtonCounter);
  return (
    <button
      onClick={() => setCurrentButtonCounter(currentButtonCounter + 1)}
      className="button"
      type="button"
    >
      {`Button : ${currentButtonCounter}`}
    </button>
  );
};

export default Button;
