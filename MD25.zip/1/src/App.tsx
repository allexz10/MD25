import React, { useState } from 'react';
import './App.scss';

const App = () => {
  const [divElementValue, setDivElementValue] = useState(0);

  return (
    <div className="container">
      <div className="div__element">
        {divElementValue * 2}
      </div>
      <button
        className="button"
        type="button"
        onClick={() => setDivElementValue(divElementValue + 1)}
      >
        {divElementValue}
      </button>
    </div>
  );
};

export default App;
