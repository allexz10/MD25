/* eslint-disable react/no-array-index-key */
import React, { useState } from 'react';
import './App.scss';

const App = () => {
  const [dropdownValue, setDropdownValue] = useState('');
  const [colors, setColors] = useState<string[]>([]);

  const [dropdownListItems, setDropdownListItems] = useState([
    'red',
    'green',
    'blue',
    'purple',
    'grey',
  ]);

  const addNewSquare = () => (dropdownValue ? setColors([...colors, dropdownValue]) : null);

  const removeLastSquare = () => {
    if (colors.length) {
      colors.pop();
      setColors([...colors]);
    }
  };

  return (
    <div className="container">
      <div className="wrapper">
        <button
          className="button button--add"
          type="button"
          onClick={() => addNewSquare()}
        >
          +
        </button>
        <button
          className="button button--remove"
          type="button"
          onClick={() => removeLastSquare()}
        >
          -
        </button>
        <select
          defaultValue=""
          className="dropdown"
          style={{ background: dropdownValue }}
          onChange={(e) => setDropdownValue(e.target.value)}
        >
          <option value="" style={{ display: 'none' }}>
            {}
          </option>
          {dropdownListItems.map((color) => (
            <option
              className="dropdown__list"
              key={color}
              style={{ background: color }}
            >
              {color}
            </option>
          ))}
        </select>
      </div>

      <div className="squares__wrapper">
        {colors.map((color) => (
          <div
            className="square"
            key={Math.random()}
            style={{ background: color }}
          />
        ))}
      </div>
    </div>
  );
};

export default App;
