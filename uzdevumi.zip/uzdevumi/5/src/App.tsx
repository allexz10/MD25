import React, { useState } from 'react';
import './App.scss';

const App = () => {
  const [inputValue, setInputValue] = useState('');
  const [checkboxChecked, setCheckboxChecked] = useState(false);

  return (
    <div className="container">
      <input
        className="input"
        type="text"
        value={
          !checkboxChecked
            ? inputValue
            : inputValue.replace(/\S/g, '*').replace(/\s/g, '*')
        }
        onChange={(e) => setInputValue(e.target.value)}
        disabled={checkboxChecked}
      />
      <label htmlFor="masked" className="masked__label">
        <input
          id="masked"
          className="checkbox"
          type="checkbox"
          checked={checkboxChecked}
          onChange={() => setCheckboxChecked(!checkboxChecked)}
        />
        Masked
      </label>
    </div>
  );
};

export default App;
