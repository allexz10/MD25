/* eslint-disable react/no-array-index-key */
import React, { useState } from 'react';
import Button from './components/Button/Button';
import './App.scss';

const App = () => {
  const [buttons, setButtons] = useState<number[]>([]);
  const [nextButtonCounter, setNextButtonCounter] = useState(0);

  const addNewButton = () => {
    if (!buttons.length) {
      setButtons([...buttons, nextButtonCounter]);
      setNextButtonCounter(0);
    } else {
      setButtons([...buttons, nextButtonCounter]);
      setNextButtonCounter(nextButtonCounter + 1);
    }
  };

  return (
    <div className="container">
      <div className="wrapper">
        <button
          className="button button--add"
          type="button"
          onClick={() => addNewButton()}
        >
          +
        </button>
      </div>
      <div className="button__wrapper">
        {buttons.map((button, index) => (
          <Button key={index} nextButtonCounter={nextButtonCounter} />
        ))}
      </div>
    </div>
  );
};

export default App;
