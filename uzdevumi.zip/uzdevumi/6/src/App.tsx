import React, { useState } from 'react';
import './App.scss';

const App = () => {
  const [buttonWidth, setButtonWidth] = useState(200);

  return (
    <div className="container">
      <button
        className="button"
        type="button"
        style={{ width: `${buttonWidth}px` }}
        onClick={() => setButtonWidth(buttonWidth + 10)}
      >
        {`width: ${buttonWidth}px`}
      </button>
    </div>
  );
};

export default App;
